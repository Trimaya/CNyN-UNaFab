WIDTHS = {20,25,35,55,75,100,150,210,300,400}
LENGTHS = {10,15,20,35,50,70,100,160,230,350}
W = 800
H = 650
x = 0                 
y = 0
for i = 1, #WIDTHS do
    for j = 1, #LENGTHS do
        symbol("MOSFET",{1,0,0,1,x,y})
        parameter("CLength",LENGTHS[j])
        parameter("CWidth",WIDTHS[i])
        x = x + W
    end
    y = y + H
    -- x = -L_INCREMENT/2*i
    x = 0
end