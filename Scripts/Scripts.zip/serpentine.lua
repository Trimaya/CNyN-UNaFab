-- CleWin Parameters --
-- Length
-- Rows
LENGTH = Length --1000
WIDTH = 4
ROW_SPACING = 2*WIDTH
PAD_SIZE = 150
ROWS = Rows --20
x = 0
y = 0
nodes = {}
for i=1,10*ROWS/2,10 do
    --Node 1
    x = 0; y = y;
    nodes[i] = x
    nodes[i+1] = y
    -- Node 2
    x = LENGTH; y = y;
    nodes[i+2] = x
    nodes[i+3] = y
    -- Node 3
    x = x; y = y + ROW_SPACING;
    nodes[i+4] = x
    nodes[i+5] = y
    -- Node 4
    x = 0; y = y;      
    nodes[i+6] = x
    nodes[i+7] = y
    -- Node 5 -- only if not last ROW
    if i == 1+10*(ROWS/2-1) then
        break
    else
        x = 0; y = y + ROW_SPACING;
        nodes[i+8] = x
        nodes[i+9] = y
    end
end
wire(0,WIDTH,nodes)
rectangle(-PAD_SIZE+WIDTH/2,-PAD_SIZE+WIDTH/2,0+WIDTH/2,0+WIDTH/2)
rectangle(-PAD_SIZE+WIDTH/2,y+PAD_SIZE-WIDTH/2,0+WIDTH/2,y-WIDTH/2)

str = string.format("%d×%dum",ROWS,LENGTH)
text(str,{1,0,0,1,10,-PAD_SIZE+WIDTH/2+20})
text("Serpentine",{1,0,0,1,10,y+20})